-- ####################################################################################
--  
--  
-- ####################################################################################

Use Hive Query and Hive Visualization tool. 

1) Find the top 20 zip codes(hint: branch_zip) by total transaction value 

SELECT  B.BRANCH_ZIP , SUM(CC.TRANSACTION_VALUE) AS TVALUE  FROM CDW_SAPP_CREDITCARD CC, CDW_SAPP_BRANCH B
 WHERE CC.BRANCH_CODE = B.BRANCH_CODE AND ROW_NUM <=20
 GROUP BY B.BRANCH_CODE 
 ORDER BY TVALUE DESC ;
 



2) Find total transaction value for each transaction type by Quarter in 2018 Hint: Find quarter from 'creditcard' 
table using month or use 'time' table if you already added transaction_id column there. 
 

 
 SELECT  TRANSACTION_TYPE, SUM(TRANSACTION_VALUE) AS TOTAL_VALUE  FROM CDW_SAPP_CREDITCARD
 GROUP BY TRANSACTION_TYPE  TVALUE  ;

  
 
 
 
--  ################################################################################################################################################################################################
 
 